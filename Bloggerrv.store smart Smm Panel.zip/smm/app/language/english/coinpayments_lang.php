<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *
 * Coinpayments
 *
 */
$lang["coinpayments_integration"] = "Coinpayments Integration";
$lang["coin_acceptance_settings"] = "Coin Acceptance Settings:";
$lang["make_sure_the_list_of_coins_have_the_enabled_status_in"] = "Make sure the list of coins have the 'Enabled' status in";
$lang["coinpayments_confirm_form"] = "Coinpayments confirm form";
$lang["choose_your_coin"] = "Choose Your Coin";


