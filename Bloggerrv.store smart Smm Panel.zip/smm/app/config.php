<?php
//Config Database 
define('DB_HOST', 'localhost');        //don't change it
define('DB_USER', 'smmprim1_32');      //enter your database username
define('DB_PASS', 'smmprim1_32');      //enter your database password
define('DB_NAME', 'smmprim1_32');      //enter you database name
define('TIMEZONE', 'Africa/Abidjan');  //don't change
define('ENCRYPTION_KEY', 'b574f0920c60bee93e628378455dfbaa'); //don't change

//This Script is Distributed by https://downloaddigital.store for free
//For installation contact https://wa.link/jhhnpg